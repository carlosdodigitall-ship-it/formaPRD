CREATE TABLE public.prompt_threads (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid NOT NULL, title text NOT NULL DEFAULT 'Nova conversa', messages jsonb NOT NULL DEFAULT '[]'::jsonb, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now());
GRANT SELECT, INSERT, UPDATE, DELETE ON public.prompt_threads TO authenticated;
GRANT ALL ON public.prompt_threads TO service_role;
ALTER TABLE public.prompt_threads ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Own threads" ON public.prompt_threads FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE INDEX prompt_threads_owner_updated ON public.prompt_threads(user_id, updated_at DESC);
CREATE TABLE public.ai_access_state (id text PRIMARY KEY, blocked boolean NOT NULL DEFAULT false, status integer, reason text, updated_at timestamptz NOT NULL DEFAULT now());
GRANT ALL ON public.ai_access_state TO service_role;
ALTER TABLE public.ai_access_state ENABLE ROW LEVEL SECURITY;