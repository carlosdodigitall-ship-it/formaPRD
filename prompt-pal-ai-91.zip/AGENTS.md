<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Build the chat surface with AI Elements and AI SDK UIMessage transport; this preserves markdown, streaming and composer behavior.
- Keep private conversation pages in the client-authenticated TanStack subtree and use route IDs as chat IDs; this prevents cross-thread message leakage.
- Store each user's thread metadata and full UIMessage transcript in Cloud under owner-scoped RLS; this enables secure cross-device history.
- Keep gateway providers in server-only helper modules and validate the bearer and thread ownership in the streaming route; this keeps credentials and private messages off public endpoints.
- Persist terminal AI access blocks in a service-only table; this prevents repeated denied requests across reloads.
