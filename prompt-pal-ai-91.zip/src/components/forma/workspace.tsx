import { useState, useMemo, useEffect, useRef } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport, type UIMessage } from "ai";
import {
  ArrowUp,
  ArrowUpRight,
  Plus,
  Search,
  PanelLeftClose,
  PanelLeft,
  MessageSquare,
  Bookmark,
  ArrowRight,
  Code2,
  Image,
  PenLine,
  Megaphone,
  SlidersHorizontal,
  ChevronDown,
  Copy,
  Check,
  LogOut,
  Trash2,
  MoreHorizontal,
  X,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Conversation,
  ConversationContent,
  ConversationScrollButton,
} from "@/components/ai-elements/conversation";
import {
  Message,
  MessageContent,
  MessageResponse,
  MessageActions,
  MessageAction,
} from "@/components/ai-elements/message";
import {
  PromptInput,
  PromptInputTextarea,
  PromptInputFooter,
  PromptInputSubmit,
} from "@/components/ai-elements/prompt-input";
import { Reasoning, ReasoningTrigger, ReasoningContent } from "@/components/ai-elements/reasoning";
import { Shimmer } from "@/components/ai-elements/shimmer";
import { useAccount } from "./auth";
import { supabase } from "@/integrations/supabase/client";
import { listThreads, createThread, editThread } from "@/lib/threads.functions";
import { toast } from "sonner";
import mark from "@/assets/forma-mark.png";

const categories = ["Todos", "Escrita", "Marketing", "Programação", "Imagens"];
const ideas = [
  {
    icon: PenLine,
    category: "Escrita",
    title: "Encontre as palavras certas",
    text: "Um texto que soa como você.",
    prompt: "Quero um prompt para escrever um artigo com uma voz autêntica e envolvente.",
    style: "rose",
  },
  {
    icon: Megaphone,
    category: "Marketing",
    title: "Faça sua marca se destacar",
    text: "Ideias que viram boas campanhas.",
    prompt:
      "Crie um prompt para uma campanha de marketing que destaque minha marca nas redes sociais.",
    style: "lime",
  },
  {
    icon: Code2,
    category: "Programação",
    title: "Do conceito ao código",
    text: "Tire seu próximo projeto do papel.",
    prompt: "Quero um prompt para desenvolver um site moderno para meu negócio.",
    style: "blue",
  },
  {
    icon: Image,
    category: "Imagens",
    title: "Dê vida à sua imaginação",
    text: "Uma imagem começa com uma ideia.",
    prompt:
      "Quero um prompt detalhado para gerar uma imagem cinematográfica de uma cidade futurista.",
    style: "peach",
  },
];
export function Workspace({
  threadId,
  initialMessages = [],
}: {
  threadId?: string;
  initialMessages?: UIMessage[];
}) {
  const { user, ready, openAuth } = useAccount();
  const navigate = useNavigate();
  const cache = useQueryClient();
  const list = useServerFn(listThreads);
  const create = useServerFn(createThread);
  const edit = useServerFn(editThread);
  const [sidebar, setSidebar] = useState(false);
  const [search, setSearch] = useState(false);
  const [filter, setFilter] = useState("");
  const [category, setCategory] = useState("Todos");
  const [view, setView] = useState("chat");
  const [input, setInput] = useState("");
  const [creating, setCreating] = useState(false);
  const [copied, setCopied] = useState<string | null>(null);
  const [autoSend, setAutoSend] = useState(false);
  const textarea = useRef<HTMLTextAreaElement>(null);
  const { data: threads = [] } = useQuery({
    queryKey: ["threads", user?.id],
    queryFn: () => list(),
    enabled: !!user,
  });
  const transport = useMemo(
    () =>
      new DefaultChatTransport({
        api: "/api/public/chat",
        body: { threadId, category },
        headers: async () => {
          const { data } = await supabase.auth.getSession();
          return data.session ? { Authorization: `Bearer ${data.session.access_token}` } : {};
        },
      }),
    [threadId, category],
  );
  const { messages, sendMessage, status, stop, error } = useChat({
    id: threadId ?? "welcome",
    messages: initialMessages,
    transport,
    onFinish: () => {
      cache.invalidateQueries({ queryKey: ["threads"] });
      textarea.current?.focus();
    },
    onError: (e) => toast.error(e.message),
  });
  const busy = status === "submitted" || status === "streaming";
  useEffect(() => {
    textarea.current?.focus();
    if (threadId) {
      const pending = sessionStorage.getItem(`forma-pending-${threadId}`);
      if (pending) {
        sessionStorage.removeItem(`forma-pending-${threadId}`);
        setInput(pending);
        setAutoSend(true);
      }
    }
  }, [threadId]);
  useEffect(() => {
    if (autoSend && input && threadId) {
      setAutoSend(false);
      sendMessage({ text: input });
      setInput("");
    }
  }, [autoSend, input, threadId, sendMessage]);
  useEffect(() => {
    if (!busy) textarea.current?.focus();
  }, [busy]);
  async function submit(text: string) {
    if (!text.trim() || busy || creating) return;
    if (!user) {
      setInput(text);
      openAuth();
      return;
    }
    if (threadId) {
      setInput("");
      sendMessage({ text });
      textarea.current?.focus();
      return;
    }
    setCreating(true);
    try {
      const thread = await create({ data: { title: text.slice(0, 60) } });
      sessionStorage.setItem(`forma-pending-${thread.id}`, text);
      await cache.invalidateQueries({ queryKey: ["threads"] });
      await navigate({ to: "/chat/$threadId", params: { threadId: thread.id } });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Não foi possível criar a conversa.");
    } finally {
      setCreating(false);
    }
  }
  async function newChat() {
    if (!user) {
      navigate({ to: "/" });
      setSidebar(false);
      return;
    }
    try {
      const thread = await create({ data: { title: "Nova conversa" } });
      cache.invalidateQueries({ queryKey: ["threads"] });
      navigate({ to: "/chat/$threadId", params: { threadId: thread.id } });
      setSidebar(false);
    } catch {
      toast.error("Não foi possível criar a conversa.");
    }
  }
  const composer = (
    <div className="composer-wrap">
      <PromptInput onSubmit={({ text }) => submit(text)} className="forma-composer">
        <PromptInputTextarea
          ref={textarea}
          aria-label="Sua ideia"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Qual ideia vamos transformar em um prompt?"
          className="min-h-20 px-5 pt-5 text-[15px]"
        />
        <PromptInputFooter className="px-4 pb-4">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="text-muted-foreground">
                <SlidersHorizontal />
                {category === "Todos" ? "Prompt personalizado" : category}
                <ChevronDown />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              {categories.map((c) => (
                <DropdownMenuItem key={c} onClick={() => setCategory(c)}>
                  {c === "Todos" ? "Geral" : c}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
          <PromptInputSubmit
            aria-label={busy ? "Parar resposta" : "Enviar ideia"}
            title={busy ? "Parar resposta" : "Enviar ideia"}
            onStop={stop}
            status={status}
            disabled={creating || (!busy && !input.trim())}
            className="ml-auto size-9 rounded-full"
          >
            {busy ? undefined : <ArrowUp />}
          </PromptInputSubmit>
        </PromptInputFooter>
      </PromptInput>
      <div className="composer-note">
        <span>Uma ideia simples. Um prompt com possibilidades.</span>
        <span className="hidden sm:inline">
          Forma AI <span className="online-dot" />
        </span>
      </div>
    </div>
  );
  return (
    <div className="workspace">
      {sidebar && <div className="sidebar-backdrop" onClick={() => setSidebar(false)} />}
      <aside className={`workspace-sidebar ${sidebar ? "is-open" : ""}`}>
        <div className="sidebar-brand">
          <Link to="/" className="brand">
            <img src={mark} width={30} height={30} alt="" />
            <span>
              forma<span className="brand-period">.</span>
            </span>
          </Link>
          <Button
            variant="ghost"
            size="icon-sm"
            title="Fechar menu"
            aria-label="Fechar menu"
            onClick={() => setSidebar(false)}
          >
            <PanelLeftClose />
          </Button>
        </div>
        <Button className="new-chat" onClick={newChat}>
          <Plus />
          Nova conversa<span className="ml-auto text-xs opacity-60">↗</span>
        </Button>
        <nav className="sidebar-nav">
          <Button
            variant="ghost"
            className={view === "chat" ? "nav-active" : ""}
            onClick={() => {
              setView("chat");
              setSearch(true);
            }}
          >
            <Search />
            Buscar conversas
          </Button>
          <Button
            variant="ghost"
            className={view === "templates" ? "nav-active" : ""}
            onClick={() => {
              setView("templates");
              setSidebar(false);
            }}
          >
            <Bookmark />
            Biblioteca de prompts<span className="new-label">NOVO</span>
          </Button>
        </nav>
        {search && (
          <div className="px-4 pb-3">
            <Input
              aria-label="Buscar conversas"
              placeholder="Buscar…"
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              autoFocus
            />
          </div>
        )}
        <div className="history">
          <div className="section-caption">SUAS CONVERSAS</div>
          {threads
            .filter((t) => t.title.toLowerCase().includes(filter.toLowerCase()))
            .map((t) => (
              <div className={`thread-row ${t.id === threadId ? "selected" : ""}`} key={t.id}>
                <Button
                  variant="ghost"
                  onClick={() => {
                    navigate({ to: "/chat/$threadId", params: { threadId: t.id } });
                    setSidebar(false);
                    setView("chat");
                  }}
                >
                  <MessageSquare />
                  <span className="truncate">{t.title}</span>
                </Button>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button
                      variant="ghost"
                      size="icon-xs"
                      title="Opções da conversa"
                      aria-label={`Opções: ${t.title}`}
                    >
                      <MoreHorizontal />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent>
                    <DropdownMenuItem
                      onClick={async () => {
                        const title = window.prompt("Nome da conversa", t.title);
                        if (title?.trim()) {
                          await edit({ data: { id: t.id, title } });
                          cache.invalidateQueries({ queryKey: ["threads"] });
                        }
                      }}
                    >
                      Renomear
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      onClick={async () => {
                        if (window.confirm("Excluir esta conversa?")) {
                          await edit({ data: { id: t.id, remove: true } });
                          cache.invalidateQueries({ queryKey: ["threads"] });
                          if (threadId === t.id) navigate({ to: "/" });
                        }
                      }}
                    >
                      <Trash2 />
                      Excluir
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            ))}
          {!threads.length && (
            <div className="history-empty">
              <MessageSquare className="size-5" />
              <p>Um espaço para suas ideias.</p>
              <span>
                {user ? "Sua próxima conversa aparece aqui." : "Entre para guardar suas conversas."}
              </span>
            </div>
          )}
        </div>
        <div className="sidebar-bottom">
          <div className="sidebar-message">
            <span className="tiny-symbol">↗</span>
            <p>
              Grandes ideias merecem
              <br />
              <strong>bons prompts.</strong>
            </p>
          </div>
          <div className="account-row">
            <div className="account-avatar">{user?.email?.[0]?.toUpperCase() ?? "F"}</div>
            <div>
              <strong>{user ? user.email?.split("@")[0] : "Seu espaço criativo"}</strong>
              <span>{user ? "Conta pessoal" : "Comece com uma ideia"}</span>
            </div>
            {user ? (
              <Button
                variant="ghost"
                size="icon-sm"
                title="Sair"
                aria-label="Sair"
                onClick={() => supabase.auth.signOut()}
              >
                <LogOut />
              </Button>
            ) : (
              <Button variant="ghost" size="sm" onClick={openAuth}>
                Entrar
                <ArrowRight />
              </Button>
            )}
          </div>
        </div>
      </aside>
      <main className="workspace-main">
        <header className="workspace-header">
          <div className="flex items-center gap-3">
            <Button
              className="mobile-menu"
              variant="ghost"
              size="icon-sm"
              onClick={() => setSidebar(true)}
              title="Abrir menu"
              aria-label="Abrir menu"
            >
              <PanelLeft />
            </Button>
            <span className="header-title">
              {view === "templates" ? "Biblioteca de prompts" : "Estúdio de prompts"}
            </span>
            <span className="version-label">BETA</span>
          </div>
          <div className="flex items-center gap-4">
            <span className="header-status">
              <span className="online-dot" />
              Sua criatividade, amplificada
            </span>
            {!user && (
              <Button variant="outline" size="sm" onClick={openAuth}>
                Entrar
                <ArrowUpRight />
              </Button>
            )}
          </div>
        </header>
        {view === "templates" ? (
          <div className="library">
            <div className="eyebrow">UM PONTO DE PARTIDA</div>
            <h1>Ideias para sua próxima ideia.</h1>
            <div className="library-grid">
              {ideas.map((i) => (
                <Button
                  key={i.title}
                  variant="outline"
                  className="library-card"
                  onClick={() => {
                    setView("chat");
                    setCategory(i.category);
                    setInput(i.prompt);
                    textarea.current?.focus();
                  }}
                >
                  <i.icon />
                  <strong>{i.title}</strong>
                  <span>{i.prompt}</span>
                  <ArrowUpRight />
                </Button>
              ))}
            </div>
          </div>
        ) : messages.length === 0 ? (
          <div className="welcome">
            <div className="welcome-inner">
              <div className="welcome-label">
                <span className="online-dot" /> MENOS TENTATIVAS. MAIS POSSIBILIDADES.
              </div>
              <img className="welcome-mark" src={mark} width={62} height={62} alt="Forma" />
              <h1>
                Sua ideia merece
                <br />
                um <span>bom prompt.</span>
              </h1>
              <p className="welcome-subtitle">
                Dê o primeiro passo. A gente ajuda a encontrar as palavras.
              </p>
              {composer}
              <div className="suggestions">
                <div className="suggestions-top">
                  <span>UM POUCO DE INSPIRAÇÃO</span>
                  <div className="category-tabs">
                    {categories.map((c) => (
                      <Button
                        key={c}
                        size="sm"
                        variant="ghost"
                        className={category === c ? "active" : ""}
                        onClick={() => setCategory(c)}
                      >
                        {c}
                      </Button>
                    ))}
                  </div>
                </div>
                <div className="idea-grid">
                  {ideas
                    .filter((i) => category === "Todos" || i.category === category)
                    .map((i) => (
                      <Button
                        variant="outline"
                        key={i.title}
                        className="idea-card"
                        onClick={() => {
                          setInput(i.prompt);
                          setCategory(i.category);
                          textarea.current?.focus();
                        }}
                      >
                        <div className="idea-card-top">
                          <span className={`category-icon ${i.style}`}>
                            <i.icon />
                          </span>
                          <ArrowUpRight className="idea-arrow" />
                        </div>
                        <strong>{i.title}</strong>
                        <span>{i.text}</span>
                      </Button>
                    ))}
                </div>
              </div>
            </div>
            <div className="welcome-footer">
              <span className="footer-star">✳</span> Feito para quem tem ideias. E quer ir além.
            </div>
          </div>
        ) : (
          <div className="active-chat">
            <Conversation className="min-h-0 flex-1">
              <ConversationContent className="mx-auto max-w-3xl gap-8 px-5 py-10">
                {messages.map((m) => (
                  <Message from={m.role} key={m.id} className="max-w-full">
                    {m.role === "assistant" && (
                      <div className="assistant-label">
                        <img src={mark} width={23} height={23} alt="" />
                        Forma
                      </div>
                    )}
                    <MessageContent
                      className={m.role === "user" ? "user-message" : "assistant-message"}
                    >
                      {m.parts.map((p, index) =>
                        p.type === "text" ? (
                          <MessageResponse key={index}>{p.text}</MessageResponse>
                        ) : p.type === "reasoning" ? (
                          <Reasoning key={index} defaultOpen={false} isStreaming={busy}>
                            <ReasoningTrigger />
                            <ReasoningContent>{p.text}</ReasoningContent>
                          </Reasoning>
                        ) : null,
                      )}
                    </MessageContent>
                    {m.role === "assistant" && (
                      <MessageActions>
                        <MessageAction
                          tooltip="Copiar prompt"
                          onClick={async () => {
                            const text = m.parts
                              .filter((p) => p.type === "text")
                              .map((p) => p.text)
                              .join("\n");
                            const code = text.match(/```[^\n]*\n([\s\S]*?)```/);
                            await navigator.clipboard.writeText(code?.[1] ?? text);
                            setCopied(m.id);
                            toast.success("Prompt copiado.");
                          }}
                        >
                          {copied === m.id ? (
                            <Check className="size-4" />
                          ) : (
                            <Copy className="size-4" />
                          )}
                        </MessageAction>
                      </MessageActions>
                    )}
                  </Message>
                ))}
                {status === "submitted" && <Shimmer>Preparando seu prompt…</Shimmer>}
                {error && (
                  <div role="alert" className="text-destructive text-sm">
                    {error.message}
                  </div>
                )}
              </ConversationContent>
              <ConversationScrollButton />
            </Conversation>
            <div className="chat-composer">{composer}</div>
          </div>
        )}
      </main>
    </div>
  );
}
