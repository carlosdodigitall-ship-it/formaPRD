import { createContext, useContext, useEffect, useState, useCallback, type ReactNode } from "react";
import type { User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";
import { useQueryClient } from "@tanstack/react-query";
import { useRouter } from "@tanstack/react-router";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import mark from "@/assets/forma-mark.png";

const AuthContext = createContext<{ user: User | null; ready: boolean; openAuth: () => void }>({
  user: null,
  ready: false,
  openAuth: () => {},
});
export const useAccount = () => useContext(AuthContext);
export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [ready, setReady] = useState(false);
  const [open, setOpen] = useState(false);
  const [mode, setMode] = useState<"login" | "signup" | "reset">("login");
  const [busy, setBusy] = useState(false);
  const cache = useQueryClient();
  const router = useRouter();
  const openAuth = useCallback(() => setOpen(true), []);
  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setUser(data.session?.user ?? null);
      setReady(true);
    });
    const { data } = supabase.auth.onAuthStateChange((event, session) => {
      setUser(session?.user ?? null);
      setReady(true);
      if (["SIGNED_IN", "SIGNED_OUT", "USER_UPDATED"].includes(event)) {
        router.invalidate();
        if (event === "SIGNED_OUT") cache.clear();
        else {
          cache.invalidateQueries();
          setOpen(false);
        }
      }
    });
    return () => data.subscription.unsubscribe();
  }, [cache, router]);
  return (
    <AuthContext.Provider value={{ user, ready, openAuth }}>
      {children}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-sm bg-card">
          <DialogHeader>
            <img src={mark} width={40} height={40} alt="Forma" className="mb-4" />
            <DialogTitle>
              {mode === "signup"
                ? "Crie sua conta"
                : mode === "reset"
                  ? "Recupere sua senha"
                  : "Seu próximo prompt começa aqui"}
            </DialogTitle>
            <DialogDescription>
              {mode === "reset"
                ? "Enviaremos um link para seu e-mail."
                : "Entre para criar prompts e guardar suas conversas."}
            </DialogDescription>
          </DialogHeader>
          {mode !== "reset" && (
            <Button
              variant="outline"
              disabled={busy}
              onClick={async () => {
                setBusy(true);
                try {
                  const result = await lovable.auth.signInWithOAuth("google", {
                    redirect_uri: window.location.origin,
                  });
                  if (result.error) toast.error(result.error.message);
                } finally {
                  setBusy(false);
                }
              }}
            >
              Continuar com Google
            </Button>
          )}
          <form
            className="grid gap-3"
            onSubmit={async (e) => {
              e.preventDefault();
              const form = new FormData(e.currentTarget);
              const email = String(form.get("email"));
              const password = String(form.get("password"));
              setBusy(true);
              try {
                if (mode === "reset") {
                  const { error } = await supabase.auth.resetPasswordForEmail(email, {
                    redirectTo: `${window.location.origin}/auth`,
                  });
                  if (error) throw error;
                  toast.success("Confira seu e-mail para recuperar a senha.");
                } else if (mode === "signup") {
                  const { error } = await supabase.auth.signUp({
                    email,
                    password,
                    options: { emailRedirectTo: window.location.origin },
                  });
                  if (error) throw error;
                  toast.success("Confira seu e-mail para confirmar sua conta.");
                } else {
                  const { error } = await supabase.auth.signInWithPassword({ email, password });
                  if (error) throw error;
                }
              } catch (err) {
                toast.error(err instanceof Error ? err.message : "Não foi possível entrar.");
              } finally {
                setBusy(false);
              }
            }}
          >
            <Input
              name="email"
              type="email"
              placeholder="Seu e-mail"
              aria-label="Seu e-mail"
              required
            />
            {mode !== "reset" && (
              <Input
                name="password"
                type="password"
                placeholder="Sua senha"
                aria-label="Sua senha"
                minLength={8}
                required
              />
            )}
            <Button disabled={busy} type="submit">
              {busy
                ? "Aguarde…"
                : mode === "signup"
                  ? "Criar conta"
                  : mode === "reset"
                    ? "Enviar link"
                    : "Entrar"}
            </Button>
          </form>
          <div className="flex flex-wrap justify-between gap-2">
            <Button variant="link" onClick={() => setMode(mode === "signup" ? "login" : "signup")}>
              {mode === "signup" ? "Já tenho conta" : "Criar uma conta"}
            </Button>
            <Button variant="link" onClick={() => setMode(mode === "reset" ? "login" : "reset")}>
              {mode === "reset" ? "Voltar" : "Esqueci a senha"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </AuthContext.Provider>
  );
}
