import { createFileRoute } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import type { UIMessage } from "ai";
import { loadThread } from "@/lib/threads.functions";
import { Workspace } from "@/components/forma/workspace";
const threadQuery = (id: string) =>
  queryOptions({
    queryKey: ["thread", id],
    queryFn: () => loadThread({ data: { id } }),
    staleTime: 0,
  });
export const Route = createFileRoute("/_authenticated/chat/$threadId")({
  head: () => ({
    meta: [
      { title: "Sua conversa — Forma" },
      {
        name: "description",
        content: "Desenvolva e refine seus prompts em uma conversa privada com o Forma.",
      },
      { property: "og:title", content: "Sua conversa — Forma" },
      { property: "og:description", content: "Um espaço para transformar ideias em prompts." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  loader: ({ context, params }) =>
    context.queryClient.ensureQueryData(threadQuery(params.threadId)),
  component: Thread,
});
function Thread() {
  const { threadId } = Route.useParams();
  const { data } = useSuspenseQuery(threadQuery(threadId));
  return (
    <Workspace
      key={threadId}
      threadId={threadId}
      initialMessages={data.messages as unknown as UIMessage[]}
    />
  );
}
