import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useAccount } from "@/components/forma/auth";
import { Workspace } from "@/components/forma/workspace";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Sua conta — Forma" },
      {
        name: "description",
        content: "Entre no Forma para guardar suas conversas e criar melhores prompts.",
      },
      { property: "og:title", content: "Sua conta — Forma" },
      { property: "og:description", content: "Seu espaço pessoal para criar prompts." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AuthPage,
});
function AuthPage() {
  const { user, ready, openAuth } = useAccount();
  const [recovery, setRecovery] = useState(false);
  useEffect(() => {
    if (window.location.hash.includes("type=recovery")) setRecovery(true);
  }, []);
  useEffect(() => {
    if (ready && !user && !recovery) openAuth();
  }, [ready, user, recovery, openAuth]);
  if (!recovery) return <Workspace />;
  return (
    <div className="flex min-h-screen items-center justify-center">
      <form
        className="grid w-80 gap-4"
        onSubmit={async (e) => {
          e.preventDefault();
          const password = String(new FormData(e.currentTarget).get("password"));
          const { error } = await supabase.auth.updateUser({ password });
          if (error) toast.error(error.message);
          else {
            toast.success("Senha atualizada.");
            window.location.assign("/");
          }
        }}
      >
        <h1 className="text-2xl">Nova senha</h1>
        <Input
          type="password"
          name="password"
          aria-label="Nova senha"
          placeholder="Nova senha"
          minLength={8}
          required
        />
        <Button type="submit">Salvar senha</Button>
      </form>
    </div>
  );
}
