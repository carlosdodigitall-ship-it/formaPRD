import { createFileRoute } from "@tanstack/react-router";
import { Workspace } from "@/components/forma/workspace";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Forma — Dê forma às suas ideias" },
      {
        name: "description",
        content:
          "Transforme suas ideias em prompts claros, criativos e prontos para usar com seu assistente de IA.",
      },
      { property: "og:title", content: "Forma — Dê forma às suas ideias" },
      {
        property: "og:description",
        content: "Sua ideia merece um bom prompt. Crie, refine e guarde seus prompts no Forma.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Workspace,
});
