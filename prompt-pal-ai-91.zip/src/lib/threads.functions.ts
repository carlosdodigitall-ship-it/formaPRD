import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

export const listThreads = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("prompt_threads")
      .select("id,title,updated_at")
      .eq("user_id", context.userId)
      .order("updated_at", { ascending: false });
    if (error) throw error;
    return data;
  });
export const loadThread = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator(z.object({ id: z.string().uuid() }))
  .handler(async ({ data, context }) => {
    const { data: thread, error } = await context.supabase
      .from("prompt_threads")
      .select("*")
      .eq("id", data.id)
      .eq("user_id", context.userId)
      .single();
    if (error) throw new Error("Conversa não encontrada.");
    return thread;
  });
export const createThread = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator(z.object({ title: z.string() }))
  .handler(async ({ data, context }) => {
    const { data: thread, error } = await context.supabase
      .from("prompt_threads")
      .insert({ user_id: context.userId, title: data.title.slice(0, 80) || "Nova conversa" })
      .select("id")
      .single();
    if (error) throw error;
    return thread;
  });
export const editThread = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator(
    z.object({
      id: z.string().uuid(),
      title: z.string().optional(),
      remove: z.boolean().optional(),
    }),
  )
  .handler(async ({ data, context }) => {
    const query = data.remove
      ? context.supabase.from("prompt_threads").delete()
      : context.supabase
          .from("prompt_threads")
          .update({ title: data.title?.slice(0, 80) ?? "Nova conversa" });
    const { error } = await query.eq("id", data.id).eq("user_id", context.userId);
    if (error) throw error;
    return { success: true };
  });
