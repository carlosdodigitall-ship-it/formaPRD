import { createClient } from "@supabase/supabase-js";
import { convertToModelMessages, validateUIMessages, type UIMessage } from "ai";
import type { Database, Json } from "@/integrations/supabase/types";
import { createResponsesCall } from "./ai/responses";
import { withLovableAiGatewayRunIdHeader } from "./ai/run-id";

export async function handleChat(request: Request) {
  const fail = (message: string, status: number) =>
    new Response(message, { status, headers: { "Content-Type": "text/plain; charset=utf-8" } });
  const url = process.env["SUPABASE_URL"];
  const key = process.env["SUPABASE_PUBLISHABLE_KEY"];
  const aiKey = process.env["LOVABLE_API_KEY"];
  if (!url || !key || !aiKey)
    return fail("A IA não está configurada. Tente novamente mais tarde.", 503);
  const token = request.headers.get("authorization")?.replace(/^Bearer /, "");
  if (!token || token.split(".").length !== 3)
    return fail("Entre na sua conta para continuar.", 401);
  const db = createClient<Database>(url, key, {
    auth: { persistSession: false, autoRefreshToken: false },
    global: { headers: { Authorization: `Bearer ${token}` } },
  });
  const { data: account, error: authError } = await db.auth.getUser(token);
  if (authError || !account.user) return fail("Sua sessão expirou. Entre novamente.", 401);
  let body: { threadId?: string; messages?: UIMessage[]; category?: string };
  try {
    body = await request.json();
  } catch {
    return fail("Mensagem inválida.", 400);
  }
  if (!body.threadId || !Array.isArray(body.messages) || body.messages.length === 0)
    return fail("Informe uma ideia para começar.", 400);
  const { data: thread, error } = await db
    .from("prompt_threads")
    .select("id,title")
    .eq("id", body.threadId)
    .eq("user_id", account.user.id)
    .single();
  if (error || !thread) return fail("Conversa não encontrada.", 404);
  let messages: UIMessage[];
  try {
    messages = await validateUIMessages({ messages: body.messages });
  } catch {
    return fail("Formato de mensagem inválido.", 400);
  }
  if (JSON.stringify(messages).length > 200000)
    return fail("Esta conversa está muito longa. Inicie uma nova conversa.", 400);
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data: state, error: stateError } = await supabaseAdmin
    .from("ai_access_state")
    .select("*")
    .eq("id", "gateway")
    .maybeSingle();
  if (stateError) return fail("Não foi possível verificar a disponibilidade da IA.", 503);
  if (state?.blocked)
    return fail(state.reason ?? "O acesso à IA está indisponível.", state.status ?? 403);
  const saved = await db
    .from("prompt_threads")
    .update({
      messages: messages as unknown as Json,
      updated_at: new Date().toISOString(),
      ...(thread.title === "Nova conversa"
        ? {
            title:
              messages
                .find((m) => m.role === "user")
                ?.parts.filter((p) => p.type === "text")
                .map((p) => p.text)
                .join(" ")
                .slice(0, 60) || "Nova conversa",
          }
        : {}),
    })
    .eq("id", thread.id);
  if (saved.error) return fail("Não foi possível salvar sua mensagem.", 500);
  const modelMessages = await convertToModelMessages(
    messages.map((m) => ({ ...m, parts: m.parts.filter((p) => p.type === "text") })),
  );
  let failure: { status: number; message: string } | undefined;
  let settleHeaders: () => void = () => {};
  const headersReady = new Promise<void>((resolve) => {
    settleHeaders = resolve;
  });
  const { result, runIdFetch } = createResponsesCall(
    request,
    {
      baseURL: "https://ai.gateway.lovable.dev/v1",
      apiKey: aiKey,
      model: "openai/gpt-6-astra",
      onGatewayResponse: async (upstream) => {
        if (!upstream.ok) {
          const payload = (await upstream
            .clone()
            .json()
            .catch(() => ({}))) as { message?: string; error?: { message?: string } };
          failure = {
            status: upstream.status,
            message:
              payload.message ??
              payload.error?.message ??
              "A IA está temporariamente indisponível.",
          };
          if ([402, 403].includes(upstream.status)) {
            const blocked = await supabaseAdmin.from("ai_access_state").upsert({
              id: "gateway",
              blocked: true,
              status: upstream.status,
              reason: failure.message,
              updated_at: new Date().toISOString(),
            });
            if (blocked.error)
              console.error("Failed to persist AI access state", blocked.error.message);
          }
        }
        settleHeaders();
      },
    },
    modelMessages,
    `Você é Forma, especialista em transformar ideias em prompts claros e úteis. Responda em português brasileiro. Categoria escolhida: ${String(body.category ?? "Geral").slice(0, 40)}. Ajude de forma prática: uma breve introdução, um prompt completo pronto para copiar em bloco de código e sugestões curtas de refinamento. Não execute o prompt: crie-o. Inclua objetivo, contexto, papel, restrições e formato de saída quando relevante. Se faltar algo essencial, faça no máximo duas perguntas, mas entregue uma primeira versão com suposições explícitas. Nunca invente fatos sobre o usuário.`,
  );
  const response = result.toUIMessageStreamResponse({
    originalMessages: messages,
    sendReasoning: true,
    onFinish: async ({ messages: completed }) => {
      const { error: saveError } = await db
        .from("prompt_threads")
        .update({ messages: completed as unknown as Json, updated_at: new Date().toISOString() })
        .eq("id", thread.id);
      if (saveError)
        throw new Error("A resposta não pôde ser salva. Copie seu prompt antes de sair.");
    },
    onError: (err) => {
      settleHeaders();
      const safe = err instanceof Error ? err.message : "Não foi possível gerar o prompt.";
      return safe;
    },
  });
  const correlated = withLovableAiGatewayRunIdHeader(response, runIdFetch);
  await headersReady;
  if (failure) return fail(failure.message, failure.status);
  return correlated;
}
